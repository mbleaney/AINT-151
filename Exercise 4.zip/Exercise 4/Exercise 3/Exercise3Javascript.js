var isLightOn = false;
var numA;
var numB;

function ToggleLight()
{
	if (isLightOn == true)
	{
		document.getElementById("lightBulb").src = "img/bulb-on.png"
	}

	else
	{
		document.getElementById("lightBulb").src = "img/bulb-off.png";
	}
}

	function AddNumbers(numA,numB)
	{
		var sum;
		sum = numA + numB;

		document.getElementById("numbers").innerHTML = sum;
	}
