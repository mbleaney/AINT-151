function AlertMessage()
{
alert("Alert meassage!");
}


function ConsoleMessage()
{
console.log("Console is active!");
}


function WhatsMyName()
{
var firstName = "Matthew"
var lastName = "Bleaney"
console.log(firstName + " " + lastName);
}
