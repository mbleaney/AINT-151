function CreatePlayer()
{
  var name;
  var colour;
  var health;
  var weapon;
  var weaponOutput;

  name = document.getElementById("playername").value;
  document.getElementById("name").innerHTML = name;

  colour = document.getElementById("playercolour").value;
  document.getElementById("colour").style.backgroundColor = colour;

  health = document.getElementById("playerhealth").value;
  document.getElementById("health").innerHTML = health;

  weapon = document.getElementById("playerweapon").value;
  if (weapon == 1)
  {
    weaponOutput = "Crossbow of much hurting"
  }
  else if (weapon == 2)
  {
    weaponOutput = "Broadsword of so slicing"
  }
  else
  {
    weaponOutput = "Wand of amaze magics"
  }
  document.getElementById("weapon").innerHTML = weaponOutput;
}
