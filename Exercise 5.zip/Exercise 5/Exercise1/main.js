var weaponsArray = ['Broadsword', 'Crossbow','Magic staff'];
var weaponSelected;



function OnLoad()
{
	for (var i = 0; i < weaponsArray.length; i++) {
		var weaponTag = "<option value='"+ i + "'>" + weaponsArray[i] + "</option>";
		document.forms[0]["weapons"].innerHTML += weaponTag;
	}
}


function SelectWeapon()
{

	console.log(document.forms[0]["weapons"].value);
	//console.log(document.getElementById("weapons").value);

	weaponSelected = document.forms[0]["weapons"].value;

	if (weaponSelected == 0)
		weaponOutput = "Broadsword"
	else if (weaponSelected == 1)
		weaponOutput = "Crossbow"
	else
		weaponOutput = "Magic Staff"

	document.getElementById("currentWeapon").innerHTML = weaponOutput;
}
