function OnLoad()
{
	SelectRoom(0);
	document.getElementById("roomTitle").innerHTML = roomArray[0].title;
	document.getElementById("roomText").innerHTML = roomArray[0].text;
	for (var i = 0; i < roomArray[0].choices.length; i++){
    var choiceTag = "<button onclick='SelectRoom(" + roomArray[0].choices[i].index + ")'>" + roomArray[0].choices[i].text + "</button>";
    document.getElementById("roomChoices").innerHTML += choiceTag;
	}
}

function SelectRoom(roomIndex)
{


}
